<?php 
/**
 * Legacy stuff can go here for backwards compatibility
 */

add_shortcode( 'display_rating_form', 'mr_rating_form' ); // @deprecated
add_shortcode( 'display_rating_result', 'mr_rating_result' ); // @deprecated
add_shortcode( 'display_top_rating_results', 'mr_rating_results_list' ); // @deprecated